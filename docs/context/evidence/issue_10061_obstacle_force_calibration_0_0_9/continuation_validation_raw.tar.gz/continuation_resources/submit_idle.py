"""Lane-local admission: decline whenever a30 is queued or idle CPUs are insufficient."""
import subprocess,sys,json,time
cpus=int(sys.argv[1]); assert 1<=cpus<=16
queue=subprocess.check_output(['squeue','-p','a30','-h','-t','PENDING','-o','%i %j'],text=True)
capacity=subprocess.check_output(['sinfo','-p','a30','-h','-o','%C'],text=True)
idle=sum(int(line.split('/')[1]) for line in capacity.splitlines() if line.strip())
receipt={'timestamp':time.time(),'queued':queue.strip(),'idle_cpus':idle,'requested_cpus':cpus,'script':sys.argv[2]}
print(json.dumps(receipt),flush=True)
if queue.strip() or idle < cpus:
 sys.exit('ADMISSION BLOCKED: queued work or insufficient idle a30 capacity')
subprocess.run(['sbatch','--parsable',sys.argv[2]],check=True)
