import sys
from scripts.validation import run_obstacle_force_preview_10061 as preview
preview.PROFILES=("legacy_v1","gradient_v3")
sys.argv=[__file__,"--mode","reset","--workers","1","--output","../out/gradient_reset"]
preview.main()
