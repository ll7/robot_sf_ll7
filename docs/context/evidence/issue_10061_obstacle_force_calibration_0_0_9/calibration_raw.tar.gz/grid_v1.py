"""Frozen diagnostic grid, issue 10061; dev seeds 1001..1010 only."""
import os
os.environ.setdefault('OMP_NUM_THREADS','1'); os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import argparse, concurrent.futures, hashlib, json, subprocess, time
from pathlib import Path
import numpy as np
import pysocialforce as pysf
from pysocialforce.config import SimulatorConfig
from robot_sf.evidence.writers import write_json
from robot_sf.research.emergent_phenomena import (ScenarioConfig, RELEASED_DEFAULT_CALIBRATION, LITERATURE_CALIBRATION, run_scenario, build_bidirectional_corridor, lane_segregation_index)
SEEDS = list(range(1001,1011))
DOORS = [1.2,2.,2.2,2.8,3.6]
FACTORS = [.03,.1,.3,1.,3.,10.]
OFFSETS = [-.57,-.3,-.1,0.,.1]
GRID = [(10.,-.57)] + [(f,b) for b in OFFSETS for f in FACTORS if (f,b)!=(10.,-.57)]
def config(f,b):
    c=SimulatorConfig(); c.scene_config.enable_group=False
    c.obstacle_force_config.factor=f; c.obstacle_force_config.threshold=b
    return c

def distance(pos, segments):
    p=np.asarray(pos)[...,None,:]; s=np.asarray(segments)
    a=s[:,:2]; v=s[:,2:]-a
    t=np.clip(((p-a)*v).sum(-1)/(v*v).sum(-1),0,1)
    return np.linalg.norm(p-a-t[...,None]*v,axis=-1).min(-1)

def simulate(state,segs,c,steps, goal_update=None, stop_x=None):
    # Builders use xyxy; EnvState requires xxyy. Explicitly checked against bytes.
    walls=[(a,c_,b,d) for a,b,c_,d in segs]
    sim=pysf.Simulator(state=state.copy(),obstacles=walls,config=c)
    traj=[sim.peds.pos().copy()]; speeds=[]
    for i in range(steps):
        if goal_update is not None: goal_update(sim)
        sim.step(); traj.append(sim.peds.pos().copy()); speeds.append(np.linalg.norm(sim.peds.vel(),axis=1))
        if stop_x is not None and sim.peds.pos()[0,0] > stop_x: break
    return np.asarray(traj), np.asarray(speeds)

def lone(f,b,seed,width):
    rng=np.random.default_rng(seed)
    segs=[(-1,2,17,2),(-1,-2,17,-2),(8,width/2,8,3),(8,-width/2,8,-3)]
    state=np.array([[2.,rng.uniform(-.05,.05),.5,0,15.,0,.5]])
    p,v=simulate(state,segs,config(f,b),1000,stop_x=9.)
    return {'seed':seed,'width':width,'passed':bool(p[-1,0,0]>9),'final_x':float(p[-1,0,0]),'speed':float(v[-100:].mean()),'min_center_distance':float(distance(p,segs).min()),'steps':len(p)-1}

def corridor(f,b,seed):
    rng=np.random.default_rng(seed); y=1.4+rng.uniform(-.01,.01)
    segs=[(-1,2,101,2),(-1,-2,101,-2)]
    state=np.array([[2,y,.5,0,100,y,.5]])
    def update(s): s.peds.state[0,4:6]=[s.peds.pos()[0,0]+1.,y]
    p,v=simulate(state,segs,config(f,b),400,goal_update=update)
    d=distance(p,segs)[:,0]
    return {'seed':seed,'min_center_distance':float(d.min()),'steady_body_clearance':float(d[100:].min()-.35),'steady_speed':float(v[100:].mean())}

def screen(pair):
    f,b=pair; rows=[lone(f,b,s,w) for s in SEEDS for w in DOORS]; cr=[corridor(f,b,s) for s in SEEDS]
    ok=all(r['passed'] and r['min_center_distance']>=.35 for r in rows) and all(r['min_center_distance']>=.35 and .2<=r['steady_body_clearance']<=.5 for r in cr)
    return {'factor':f,'offset':b,'screen_pass':ok,'lone':rows,'corridor':cr}

def crowd(f,b,seed,width,speed):
    rng=np.random.default_rng(seed); n=60
    xs,ys=np.meshgrid(np.arange(6)*.75+.8,np.linspace(-3.5,3.5,10))
    x=xs.ravel()+rng.uniform(-.015,.015,n); y=ys.ravel()+rng.uniform(-.015,.015,n)
    # Unidirectional queue; centreline waypoint 1m beyond plane, then clear downstream.
    state=np.column_stack([x,y,np.full(n,speed/1.3),np.zeros(n),np.full(n,9.),np.zeros(n),np.full(n,.5)])
    segs=[(-1,4,25,4),(-1,-4,25,-4),(-1,-4,-1,4),(8,width/2,8,5),(8,-width/2,8,-5)]
    def update(s):
        crossed=s.peds.pos()[:,0]>8.5
        s.peds.state[crossed,4]=24.
    p,v=simulate(state,segs,config(f,b),1200,goal_update=update)
    crossed=(p[:,:,0]>=8)
    times=[]
    for j in range(n):
        tt=np.flatnonzero(crossed[:,j]);
        if len(tt): times.append(float(tt[0]*.1))
    times.sort(); count=len(times)
    # Same first-to-last convention as published table, finite-N diagnostic.
    flow=count/(times[-1]-times[0]) if count>=2 and times[-1]>times[0] else 0.
    return {'seed':seed,'width':width,'desired_speed':speed,'crossed':count,'flow':flow,'specific_flow':flow/width,'min_center_distance':float(distance(p,segs).min()),'crossing_times':times}

def flow_task(task):
    f,b=task; return {'factor':f,'offset':b,'flow':[crowd(f,b,s,w,sp) for s in SEEDS for w in [.8,1.,1.2,2.,3.6] for sp in [.65,1.3]]}

def lanes(pair):
    # Use canonical builder/order parameter with an explicit obstacle layout conversion.
    import robot_sf.research.emergent_phenomena as ep
    from dataclasses import replace
    orig=ep._BUILDERS['bidirectional_corridor']
    def corrected(c,cal):
        state,walls,dirs=orig(c,cal)
        return state,[(a,c_,b,d) for a,b,c_,d in walls],dirs
    ep._BUILDERS['bidirectional_corridor']=corrected
    f,b=pair; rows=[]
    for s in SEEDS:
        sc=ScenarioConfig('bidirectional_corridor',24.,2.5,24,s,400)
        for cal in [RELEASED_DEFAULT_CALIBRATION,LITERATURE_CALIBRATION]:
            r=run_scenario(sc,cal,config(f,b))
            rows.append({'seed':s,'calibration':cal.name,'order_parameters':r.order_parameters,'min_center_distance':float(distance(r.trajectory.positions,[(-1,2.5,25,2.5),(-1,-2.5,25,-2.5)]).min())})
    return {'factor':f,'offset':b,'lanes':rows}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['screen','flow','lanes'],required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--workers',type=int,default=16);ap.add_argument('--pairs',type=Path)
    a=ap.parse_args();assert 1<=a.workers<=16;assert all(1001<=s<=1010 for s in SEEDS)
    pairs=GRID if a.pairs is None else [tuple(p) for p in json.loads(a.pairs.read_text())]
    print('RESOLVED SEEDS',SEEDS,'PAIRS',pairs,flush=True)
    a.out.mkdir(parents=True,exist_ok=True)
    task={'screen':screen,'flow':flow_task,'lanes':lanes}[a.stage]
    with concurrent.futures.ProcessPoolExecutor(a.workers) as pool:
        futures={pool.submit(task,p):p for p in pairs}
        for fut in concurrent.futures.as_completed(futures):
            row=fut.result();pair=futures[fut]
            write_json(a.out/f'{a.stage}_{pair[0]}_{pair[1]}.json',row)
            print('DONE',a.stage,pair,row.get('screen_pass'),flush=True)
    write_json(a.out/f'{a.stage}_manifest.json',{'seeds':SEEDS,'grid':pairs,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'slurm_job':os.environ.get('SLURM_JOB_ID'),'workers':a.workers})
if __name__=='__main__': main()
