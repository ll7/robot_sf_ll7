"""Matched 0.0.8 pedestrian pair kernel, otherwise frozen diagnostic grid."""
import grid
base_config=grid.config
def config(f,b):
    c=base_config(f,b)
    c.social_force_config.kernel_version='wrapped_v2'
    return c
grid.config=config
if __name__=='__main__':grid.main()
