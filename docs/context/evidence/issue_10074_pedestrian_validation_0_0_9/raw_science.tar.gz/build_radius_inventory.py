"""Inventory operational literal sites; numeric near-miss lists are kept separate."""
import subprocess,re,json,ast
from pathlib import Path
root=Path('/home/luttkule/pedval')
files=subprocess.check_output(['git','ls-files'],cwd=root,text=True).splitlines()
rows=[]
for path in files:
 if not path.startswith(('robot_sf/','fast-pysf/pysocialforce/','configs/','scripts/')) or not path.endswith(('.py','.yaml','.json')):continue
 text=(root/path).read_text(errors='replace')
 doclines=set()
 if path.endswith('.py'):
  for node in ast.walk(ast.parse(text)):
   if isinstance(node,ast.Expr) and isinstance(node.value,ast.Constant) and isinstance(node.value.value,str):doclines.update(range(node.lineno,node.end_lineno+1))
 for number,line in enumerate(text.splitlines(),1):
  if number in doclines:continue
  if not re.search(r'(?<![\d.])0\.(?:4(?:0)?|35)(?!\d)',line) or not re.search(r'radius|radii|RADIUS|RADII',line):continue
  if line.lstrip().startswith(('#','"""')):continue
  if 'robot_radius' in line and not re.search(r'ped|agent_radius',line,re.I):continue
  if path in ['scripts/benchmark/run_fidelity_sensitivity_campaign.py','scripts/validation/check_scenario_archetype_reachability.py','robot_sf/render/audit_workbench.py','configs/diagnostics/footprint_orientation_v1.yaml','scripts/analysis/run_scenario_belief_uncertainty_diagnostic_issue_2546.py']:continue
  if 'near_miss_radius' in line or 'robot_body_radius_m' in line:continue
  if path=='configs/research/fidelity_sensitivity_v1.yaml' and number==177:continue
  if path=='configs/scenarios/single/issue_2526_cyclist_vru_smoke.yaml':continue
  category='simulation truth'
  if any(x in path for x in ['planner/','baselines/','configs/','observation_noise','map_runner_observations','robot_env.py','map_runner_trace']):category='planner/observation assumption'
  if 'fast-pysf/pysocialforce/config.py' in path or 'research/emergent' in path:category='simulation force-kernel calibration (distinct from physical truth)'
  if 'benchmark/runner.py' in path:category='alternate runner geometry default (simulation/metric truth; legacy mismatch)'
  if 'radius_sensitivity_gate0_audit' in path:category='historical audit constant; not live radius control'
  if '/render/' in path or 'sim_view' in path:category='rendering assumption'
  if 'collision_definition_inventory' in path or 'last_avoidable_fixtures' in path or 'canary' in path or path.startswith('scripts/'):category='diagnostic/fixture assumption; inspect caller before treating as truth'
  if 'last_avoidable_fixtures' in path:category='diagnostic combined contact threshold, not a pedestrian body radius'
  if 'safety_wrapper' in path or 'guard' in path:category='planner/guard assumption'
  if path.startswith('configs/benchmarks/') and 'mean_matched' in path or 'geometryless_forced' in path:category='simulation truth; population body-size setup'
  if path.startswith('configs/research/') and ('ped_radius' in line or 'pedestrian_radius' in line):category='simulation/metric truth; sensitivity setup'
  if path=='configs/diagnostics/footprint_orientation_v1.yaml':category='simulation footprint diagnostic setup'
  if path.endswith('pedestrian_validation_0_0_9.json'):category='diagnostic baseline force calibration' if 'force_radius' in line else 'diagnostic physical truth'
  rows.append({'path':path,'line':number,'literal':line.strip(),'classification':category})
rows.append({'path':'robot_sf/benchmark/observation_noise.py','line':501,'literal':'np.full((positions.shape[0],), 0.35, dtype=float),','classification':'planner/observation assumption; multiline range-occlusion radius'})
rows.sort(key=lambda x:(x['path'],x['line']))
Path('/home/luttkule/pedval_artifacts/radius_inventory.json').write_text(json.dumps({'source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'tracked operational Python/YAML/JSON; excludes tests, evidence copies and non-radius 0.4/0.35 weights/speeds','rows':rows},indent=2)+'\n')
lines=['| site | literal | classification |','|---|---|---|']
for r in rows:lines.append('| '+r['path']+':'+str(r['line'])+' | `'+r['literal'].replace('|','/')+'` | '+r['classification']+' |')
Path('/home/luttkule/pedval_artifacts/radius_inventory.md').write_text('\n'.join(lines)+'\n')
print(len(rows),'radius literal sites')
