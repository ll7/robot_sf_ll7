"""Diagnostic exponential wall family only, dev seeds1001..1010; not production."""
import grid
import argparse,concurrent.futures,json,hashlib,subprocess,os
from pathlib import Path
import numpy as np
from numba import njit
from pysocialforce.forces import ObstacleForce
@njit
def kernel(pos,obs,A,B,r):
    out=np.zeros_like(pos)
    for i in range(len(pos)):
        for j in range(len(obs)):
            ax,ay,bx,by=obs[j,:4]
            vx,vy=bx-ax,by-ay
            den=vx*vx+vy*vy
            t=max(0.,min(1.,((pos[i,0]-ax)*vx+(pos[i,1]-ay)*vy)/den)) if den else 0.
            dx,dy=pos[i,0]-ax-t*vx,pos[i,1]-ay-t*vy
            d=np.sqrt(dx*dx+dy*dy)
            if d>1e-12:
                f=A*np.exp(min(100.,(r-d)/B))/d
                out[i,0]+=f*dx;out[i,1]+=f*dy
    return out

def force(self):
    return kernel(self.get_peds(),self.get_obstacles(),float(self.config.factor),float(self.config.threshold),self.get_agent_radius())
ObstacleForce.__call__=force

def screen(pair):
    A,B=pair
    rows=[grid.lone(A,B,s,w,t) for s in grid.SEEDS for w in [.8,1.,*grid.DOORS] for t in [0.,.1]]
    cr=[grid.corridor(A,B,s) for s in grid.SEEDS]
    safety=[]
    for s in grid.SEEDS:
        for speed in [.65,1.3]:
            rng=np.random.default_rng(s)
            state=np.array([[2.,1.+rng.uniform(-.01,.01),0.,speed/1.3,2.,4.,.5]])
            p,v=grid.simulate(state,[(-1,2,101,2)],grid.config(A,B),300)
            safety.append(float(grid.distance(p,[(-1,2,101,2)]).min()))
    passed=all(r['passed'] and r['min_center_distance']>=.35 for r in rows) and min(safety)>=.35 and all(.2<=r['steady_body_clearance']<=.5 for r in cr)
    return {'amplitude':A,'range':B,'screen_pass':passed,'lone':rows,'corridor':cr,'direct_wall_min_center_distance':min(safety)}
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['screen','flow']);ap.add_argument('--pairs',type=Path);ap.add_argument('--out',type=Path);ap.add_argument('--workers',type=int,default=12);a=ap.parse_args()
    assert 1<=a.workers<=16
    pairs=json.loads(a.pairs.read_text()) if a.pairs else [(A,B) for A in [10,25,50,100,200] for B in [.01,.02,.04,.08,.16]]
    a.out.mkdir(parents=True,exist_ok=True)
    tasks=pairs if a.stage=='screen' else [(A,B,s) for A,B in pairs for s in grid.SEEDS]
    print('RESOLVED SEEDS',grid.SEEDS,'GRID',pairs,flush=True)
    rows=[]
    with concurrent.futures.ProcessPoolExecutor(a.workers) as pool:
        futs=[pool.submit(screen if a.stage=='screen' else grid.flow_task,t) for t in tasks]
        for f in concurrent.futures.as_completed(futs):
            row=f.result();rows.append(row);grid.write_json(a.out/f'row_{len(rows)}.json',row);print('DONE',len(rows),row.get('amplitude'),row.get('range'),row.get('screen_pass'),flush=True)
    grid.write_json(a.out/'manifest.json',{'law':'A*exp((r-d)/B)*unit_normal','seeds':grid.SEEDS,'grid':pairs,'rows':rows,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'slurm_job':os.environ.get('SLURM_JOB_ID')})
if __name__=='__main__':main()
