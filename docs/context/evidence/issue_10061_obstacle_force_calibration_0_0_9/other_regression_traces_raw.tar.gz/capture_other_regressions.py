"""Numerically transparent post-loop capture of paired canonical doorway episodes."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
import numpy as np
from robot_sf.evidence.writers import write_json
from scripts.validation import run_obstacle_force_preview_10061 as preview
from robot_sf.benchmark.map_runner import map_runner_episode as episode

ROOT=Path.cwd()
OUT=ROOT.parent/'out/other_regression_mechanisms'
OUT.mkdir(parents=True,exist_ok=True)
original=episode._compute_post_loop_metrics
context={}
traces=[]
def capture(**kwargs):
    index=context['index'];context['index']+=1
    prefix=f"{context['arm']}__{context['scenario']}__{context['profile']}__{index}"
    map_def=kwargs['map_def']
    segments=[]
    for obstacle in map_def.obstacles:
        for x1,x2,y1,y2 in obstacle.lines:
            segments.append((x1,y1,x2,y2))
    for bound in map_def.bounds:
        if len(bound)==4:
            a,c,b,d=bound
            segments.append((a,b,c,d))
        else:
            a,b=bound
            segments.append((*a,*b))
    positions=episode._stack_ped_positions(kwargs['ped_positions'])
    robots=np.asarray(kwargs['robot_positions'])
    np.savez_compressed(OUT/f'{prefix}.npz',pedestrians=positions,robot=robots,segments=np.asarray(segments),goal=np.asarray(kwargs['goal_vec']),ped_radius=kwargs['config'].sim_config.ped_radius,robot_radius=kwargs['config'].robot_config.radius,obstacle_wkt=np.array([obstacle.geometry.wkt for obstacle in map_def.obstacles if obstacle.geometry is not None]))
    traces.append({'artifact':f'{prefix}.npz','episode_index':index,'scenario':context['scenario'],'arm':context['arm'],'profile':context['profile'],'steps':len(robots),'sha256':hashlib.sha256((OUT/f'{prefix}.npz').read_bytes()).hexdigest()})
    return original(**kwargs)
episode._compute_post_loop_metrics=capture
matrix=ROOT/'configs/scenarios/classic_interactions_francis2023_release_0_0_8_v1.yaml'
rows=[dict(x) for x in preview.load_scenarios(matrix)]
horizons=preview.yaml.safe_load((ROOT/'configs/benchmarks/obstacle_force_calibration_0_0_9/preview_horizons.yaml').read_text())['scenarios']
print('RESOLVED SEEDS',preview.SEEDS,flush=True)
cells=[('classic_bottleneck_high', 'orca'), ('classic_bottleneck_medium', 'orca'), ('classic_cross_trap_high', 'orca'), ('classic_merging_medium', 'orca'), ('classic_overtaking_medium', 'orca'), ('francis2023_blind_corner', 'orca'), ('francis2023_exiting_elevator', 'orca'), ('classic_cross_trap_medium', 'social_force'), ('francis2023_crowd_navigation', 'social_force'), ('francis2023_robot_crowding', 'social_force')]
part=int(sys.argv[1])
for name,arm in cells[part::2]:
    scenario=next(x for x in rows if x['name']==name)
    for profile in preview.PROFILES:
        context.update(scenario=name,arm=arm,profile=profile,index=0)
        result=preview.run_cell((ROOT,matrix,OUT,scenario,horizons[name]['recommended_horizon_steps'],arm,profile))
        write_json(OUT/f'{arm}__{name}__{profile}__receipt.json',result)
        print('DONE',name,arm,profile,flush=True)
write_json(OUT/f'manifest_{part}.json',{'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'slurm_job':os.environ.get('SLURM_JOB_ID'),'seeds':list(preview.SEEDS),'traces':traces,'hook':'post-loop capture only; returns original result'})
