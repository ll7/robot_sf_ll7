"""Analyze source-bound post-loop traces; retain contact/flow distinction."""
from pathlib import Path
import hashlib,json
import numpy as np
from shapely.geometry import Polygon
from shapely import contains_xy
from robot_sf.evidence.writers import write_json
from scripts.validation.calibrate_obstacle_force_10061 import distance
ROOT=Path('/home/luttkule/wallcal_artifacts')
OUT=ROOT/'doorway_mechanisms_v2'
manifest=json.loads((OUT/'manifest.json').read_text())
rows=[]
for item in manifest['traces']:
    path=OUT/item['artifact'];assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
    name=item['scenario'];arm=item['arm'];profile=item['profile'];index=item['episode_index']
    records=[json.loads(x) for x in (OUT/f'{arm}__{name}__{profile}.jsonl').read_text().splitlines()]
    record=records[index]
    original={r['seed']:r for r in [json.loads(x) for x in (ROOT/'preview'/f'{arm}__{name}__{profile}.jsonl').read_text().splitlines()]}
    assert record['outcome']==original[record['seed']]['outcome']
    assert record['steps']==original[record['seed']]['steps']
    data=np.load(path);p=data['pedestrians'];robot=data['robot'];segments=data['segments']
    minimum_pair=float(np.nanmin(np.linalg.norm(p-robot[:,None,:],axis=-1)))
    assert np.isclose(minimum_pair,record['metrics']['min_distance']), (path,minimum_pair,record['metrics']['min_distance'])
    wall=distance(p,segments)
    inside=np.zeros(p.shape[:2],dtype=bool)
    # The captured classic doorway map consists of six closed rectangular polygons.
    for start in range(0,len(segments)-4,4):
        poly=Polygon(segments[start:start+4,:2]);assert poly.is_valid
        inside|=contains_xy(poly,p[:,:,0],p[:,:,1])
    signed=np.where(inside,-wall,wall)
    low,high=12.240171,15.537233
    in_door=(p[:,:,0]>=21)&(p[:,:,0]<=23)&(p[:,:,1]>=low)&(p[:,:,1]<=high)
    near_door=(p[:,:,0]>=20)&(p[:,:,0]<=24)&(p[:,:,1]>=low-1)&(p[:,:,1]<=high+1)
    crossed=(p[:-1,:,0]-22)*(p[1:,:,0]-22)<0
    y=(p[:-1,:,1]+p[1:,:,1])/2
    valid=crossed&(y>=low+.4)&(y<=high-.4)
    outside_gap=crossed&((y<low)|(y>high))
    before=robot[0,0];goal=data['goal'];side=1 if before>22 else -1
    progress=side*(before-robot[-1,0])
    rows.append({'scenario':name,'arm':arm,'profile':profile,'seed':record['seed'],'replay_matches_original_outcome_and_steps':True,'success':record['metrics']['success'],'termination':record['termination_reason'],'steps':record['steps'],'pedestrians':p.shape[1],'unique_pedestrians_crossing_door_plane_inside_body_clear_gap':int(valid.any(axis=0).sum()),'door_plane_crossing_events':int(valid.sum()),'crossing_events_outside_gap':int(outside_gap.sum()),'door_occupancy_mean':float(in_door.sum(axis=1).mean()),'near_door_occupancy_mean':float(near_door.sum(axis=1).mean()),'min_signed_center_wall_distance_m':float(np.nanmin(signed)),'max_physical_wall_penetration_m':float(max(0.,.4-np.nanmin(signed))),'footprint_penetration_sample_fraction':float(np.mean(signed<.4)),'robot_progress_toward_door_m':float(progress),'robot_final_xy':robot[-1].tolist(),'robot_goal_xy':goal.tolist(),'robot_min_ped_center_distance_m':minimum_pair,'robot_collision':record['outcome']['collision_event'],'robot_wall_collision_count':record['metrics']['wall_collisions'],'failure_to_progress':record['metrics']['failure_to_progress'],'trace_artifact':item['artifact']})
aggregates=[]
for name in sorted({r['scenario'] for r in rows}):
 for arm in ['goal','orca','social_force']:
  for profile in ['legacy_v1','calibrated_v2']:
   cell=[r for r in rows if r['scenario']==name and r['arm']==arm and r['profile']==profile]
   aggregates.append({'scenario':name,'arm':arm,'profile':profile,'successes':sum(r['success'] for r in cell),'collisions':sum(r['robot_collision'] for r in cell),'timeouts':sum(r['termination']=='terminated' for r in cell),'mean_unique_crossing_pedestrians':float(np.mean([r['unique_pedestrians_crossing_door_plane_inside_body_clear_gap'] for r in cell])),'mean_near_door_occupancy':float(np.mean([r['near_door_occupancy_mean'] for r in cell])),'max_wall_penetration_m':max(r['max_physical_wall_penetration_m'] for r in cell),'mean_robot_progress_m':float(np.mean([r['robot_progress_toward_door_m'] for r in cell]))})
write_json(ROOT/'doorway_mechanism_summary.json',{'source_head':manifest['source_head'],'trace_hook':'post-loop capture; no numerical mutation','seeds':list(range(1001,1006)),'rows':rows,'aggregates':aggregates,'analysis_limit':'Associations and empty-crowd control; no claim of empirical realism or a unique causal mediator.'})
for r in aggregates: print(r)
