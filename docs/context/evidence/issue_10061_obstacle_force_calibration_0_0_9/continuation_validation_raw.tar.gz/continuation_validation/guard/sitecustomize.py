"""WALLCAL held-out seed guard: refuse env/global seeding with retired 111..140 or sealed 0.0.8 seeds (before any step)."""
import importlib.abc, importlib.machinery, os, sys
_SEALED = {50036,50140,50331,50403,50813,51339,51709,51767,52094,52175,52257,52671,52850,52971,53020,53198,53239,53636,53671,53779,55022,55379,55568,56170,56966,57077,57113,57494,57943,59019}
_LOG = os.environ.get("WALLCAL_GUARD_LOG", "/home/luttkule/wallcal_artifacts/guard_trips.log")
class HeldOutSeedRefused(BaseException):
    pass
def _check(seed, where):
    try:
        s = int(seed)
    except Exception:
        return
    _extra = {int(x) for x in os.environ.get('WALLCAL_GUARD_EXTRA','').split(',') if x}
    if 111 <= s <= 140 or s in _SEALED or s in _extra:
        with open(_LOG, "a") as f:
            f.write(f"{os.environ.get('PYTEST_CURRENT_TEST','?')}\t{where}\t{s}\t{os.getpid()}\n")
        raise HeldOutSeedRefused(f"held-out seed {s} refused at {where}")
def _patch(name, mod):
    if name == "gymnasium.utils.seeding":
        orig = mod.np_random
        def np_random(seed=None, *a, **k):
            _check(seed, "gymnasium.np_random"); return orig(seed, *a, **k)
        mod.np_random = np_random
    elif name == "robot_sf.common.seed":
        orig = mod.set_global_seed
        def set_global_seed(seed, *a, **k):
            _check(seed, "set_global_seed"); return orig(seed, *a, **k)
        mod.set_global_seed = set_global_seed
_TARGETS = {"gymnasium.utils.seeding", "robot_sf.common.seed"}
class _Finder(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path, target=None):
        if fullname not in _TARGETS:
            return None
        spec = importlib.machinery.PathFinder.find_spec(fullname, path)
        if spec is None or spec.loader is None:
            return spec
        loader = spec.loader; orig_exec = loader.exec_module
        def exec_module(module, _o=orig_exec, _n=fullname):
            _o(module); _patch(_n, module)
        loader.exec_module = exec_module
        return spec
sys.meta_path.insert(0, _Finder())
