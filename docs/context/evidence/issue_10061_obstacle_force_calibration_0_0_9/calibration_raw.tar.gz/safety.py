import sys,json,glob
sys.path.insert(0,'/home/luttkule/wallcal-10061')
from grid import *
rows=[];pairs=[]
for p in glob.glob('../out/screen/screen_*.json'):
 d=json.load(open(p))
 if not d.get('screen_pass'):continue
 f,b=d['factor'],d['offset']; dd=[]
 for s in SEEDS:
  for speed in [.65,1.3]:
   rng=np.random.default_rng(s)
   state=np.array([[2.,1.+rng.uniform(-.01,.01),0.,speed/1.3,2.,4.,.5]])
   tr,v=simulate(state,[(-1,2,101,2)],config(f,b),300)
   dd.append(float(distance(tr,[(-1,2,101,2)]).min()))
 ok=min(dd)>=.35
 rows.append({'factor':f,'offset':b,'min_center_distance':min(dd),'pass':ok})
 if ok:pairs.append([f,b])
write_json(Path('../out/safety.json'),{'rows':rows})
Path('../pairs.json').write_text(json.dumps(pairs))
print('SAFETY',rows,'PAIRS',pairs,flush=True)
