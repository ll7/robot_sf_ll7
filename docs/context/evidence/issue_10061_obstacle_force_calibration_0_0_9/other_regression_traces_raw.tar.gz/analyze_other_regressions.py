from pathlib import Path
import hashlib,json
import numpy as np
from shapely import from_wkt,contains_xy
from robot_sf.evidence.writers import write_json
from scripts.validation.calibrate_obstacle_force_10061 import distance
ROOT=Path('/home/luttkule/wallcal_artifacts');OUT=ROOT/'other_regression_mechanisms';rows=[]
for mf in sorted(OUT.glob('manifest_*.json')):
 manifest=json.loads(mf.read_text())
 for item in manifest['traces']:
  path=OUT/item['artifact'];assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
  name,arm,profile,index=item['scenario'],item['arm'],item['profile'],item['episode_index']
  record=[json.loads(x) for x in (OUT/f'{arm}__{name}__{profile}.jsonl').read_text().splitlines()][index]
  original={r['seed']:r for r in [json.loads(x) for x in (ROOT/'preview'/f'{arm}__{name}__{profile}.jsonl').read_text().splitlines()]}
  assert record['outcome']==original[record['seed']]['outcome'] and record['steps']==original[record['seed']]['steps'],(name,arm,profile,index)
  data=np.load(path);p,robot=data['pedestrians'],data['robot'];radius=float(data['ped_radius']);steps=p.shape[0]
  separation=np.linalg.norm(p-robot[:,None,:],axis=-1)
  minimum=float(np.nanmin(separation));assert np.isclose(minimum,record['metrics']['min_distance'])
  wall=distance(p,data['segments']);inside=np.zeros(p.shape[:2],dtype=bool)
  for wkt in data['obstacle_wkt']:
   poly=from_wkt(str(wkt));inside |= contains_xy(poly,p[:,:,0],p[:,:,1])
  signed=np.where(inside,-wall,wall)
  dp=np.linalg.norm(np.diff(p,axis=0),axis=-1)
  dt=.1
  goal=data['goal'];toward=np.linalg.norm(robot[0]-goal)-np.linalg.norm(robot[-1]-goal)
  row={'scenario':name,'arm':arm,'profile':profile,'seed':record['seed'],'success':record['metrics']['success'],'termination':record['termination_reason'],'steps':record['steps'],'replay_matches_original_outcome_and_steps':True,'pedestrians':p.shape[1],'mean_ped_speed_m_s':float(dp.mean()/dt),'mean_ped_net_displacement_m':float(np.linalg.norm(p[-1]-p[0],axis=-1).mean()),'mean_ped_path_length_m':float(dp.sum(axis=0).mean()),'near_robot_occupancy_mean_within_3m':float((separation<3).sum(axis=1).mean()),'max_physical_wall_penetration_m':float(max(0.,radius-np.nanmin(signed))),'footprint_penetration_sample_fraction':float(np.mean(signed<radius)),'robot_min_ped_center_distance_m':minimum,'robot_collision':record['outcome']['collision_event'],'robot_wall_collision_count':record['metrics']['wall_collisions'],'exact_collision_events':record['event_ledger']['collision_events'],'trace_artifact':item['artifact'],'trace_sha256':item['sha256']}
  rows.append(row)
aggregates=[]
for name,arm in sorted({(x['scenario'],x['arm']) for x in rows}):
 for profile in ['legacy_v1','calibrated_v2']:
  cell=[x for x in rows if (x['scenario'],x['arm'],x['profile'])==(name,arm,profile)]
  aggregates.append({'scenario':name,'arm':arm,'profile':profile,'successes':sum(x['success'] for x in cell),'collisions':sum(x['robot_collision'] for x in cell),'timeouts':sum(x['termination']=='terminated' for x in cell),'mean_ped_speed_m_s':float(np.mean([x['mean_ped_speed_m_s'] for x in cell])),'mean_ped_path_length_m':float(np.mean([x['mean_ped_path_length_m'] for x in cell])),'mean_near_robot_occupancy':float(np.mean([x['near_robot_occupancy_mean_within_3m'] for x in cell])),'max_wall_penetration_m':max(x['max_physical_wall_penetration_m'] for x in cell)})
write_json(ROOT/'other_regression_summary.json',{'source_head':manifest['source_head'],'seeds':list(range(1001,1006)),'trace_hook':'transparent post-loop; 100 episodes restricted to ten previously regressing non-doorway rows','rows':rows,'aggregates':aggregates,'analysis_limit':'Time-averaged traffic measurements are duration-dependent associations; wall-penetration differences flag model defects rather than prove a unique cause. No human-realism admission.'})
for x in aggregates:print(x)
