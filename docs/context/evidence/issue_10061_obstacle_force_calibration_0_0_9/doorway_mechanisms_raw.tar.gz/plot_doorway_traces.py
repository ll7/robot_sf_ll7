"""Source-backed figure of paired ORCA doorway trajectories (seed 1001)."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path('/home/luttkule/wallcal_artifacts')
s=json.loads((ROOT/'doorway_mechanism_summary.json').read_text())
fig,axes=plt.subplots(3,2,figsize=(12,11),sharex=True,sharey=True)
for i,name in enumerate(['classic_doorway_low','classic_doorway_medium','classic_doorway_high']):
 for j,profile in enumerate(['legacy_v1','calibrated_v2']):
  ax=axes[i,j]
  row=next(r for r in s['rows'] if r['scenario']==name and r['arm']=='orca' and r['profile']==profile and r['seed']==1001)
  data=np.load(ROOT/'doorway_mechanisms_v2'/row['trace_artifact']);p=data['pedestrians'];r=data['robot'];segments=data['segments']
  for k in range(0,len(segments)-4,4):
   corners=segments[k:k+4,:2];ax.fill(corners[:,0],corners[:,1],color='#d9dee7',zorder=0)
  for actor in range(p.shape[1]):
   ax.plot(p[:,actor,0],p[:,actor,1],color='#d97706',alpha=.5,lw=1,label='pedestrian' if actor==0 else None)
   ax.scatter(*p[0,actor],color='#d97706',s=12,marker='o');ax.scatter(*p[-1,actor],color='#d97706',s=22,marker='x')
  ax.plot(r[:,0],r[:,1],color='#1d4ed8',lw=2.5,label='robot')
  ax.scatter(*r[0],s=35,color='#1d4ed8',marker='o');ax.scatter(*r[-1],s=55,color='#1d4ed8',marker='x')
  ax.scatter(*data['goal'],color='#15803d',s=70,marker='*',label='goal')
  ax.set_title(f"{name.replace('classic_doorway_','').title()} · {profile}\n{row['termination']}; {row['unique_pedestrians_crossing_door_plane_inside_body_clear_gap']} pedestrians cross")
  ax.set_xlim(14,33);ax.set_ylim(8.5,19.5);ax.set_aspect('equal');ax.grid(alpha=.15);ax.set_xlabel('x (m)');ax.set_ylabel('y (m)')
axes[0,0].legend(loc='upper left',fontsize=8)
fig.suptitle('ORCA doorway preview: paired development seed 1001\nCircle = start; cross = final position. Post-loop capture leaves episode dynamics unchanged.',fontsize=12)
fig.tight_layout(rect=(0,0,1,.95))
for suffix in ['png','pdf']:fig.savefig(ROOT/f'doorway_traces.{suffix}',dpi=180)
