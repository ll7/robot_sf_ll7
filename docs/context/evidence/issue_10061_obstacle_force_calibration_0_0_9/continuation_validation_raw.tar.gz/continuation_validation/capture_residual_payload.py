"""Read-only failure observability for a mocked diagnostic release test."""
from pathlib import Path
from robot_sf.evidence.writers import write_json

def pytest_exception_interact(node, call, report):
    if not report.failed or call.excinfo is None:
        return
    for entry in call.excinfo.traceback:
        if str(entry.path).endswith('test_run_benchmark_release.py'):
            value=entry.frame.f_locals.get('payload')
            if isinstance(value,dict):
                write_json(Path('../out/release_failure_payload.json'),{'nodeid':node.nodeid,'payload':value})
