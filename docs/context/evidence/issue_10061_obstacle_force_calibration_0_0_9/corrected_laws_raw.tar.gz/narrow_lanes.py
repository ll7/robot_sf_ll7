"""Canonical lane probe at 3.0/3.6 m; physical initial wall clearance adapted explicitly."""
import concurrent.futures,hashlib,json,os,subprocess
from pathlib import Path
import numpy as np
import robot_sf.research.emergent_phenomena as ep
from scripts.validation import compare_obstacle_laws_10061 as compare
from robot_sf.evidence.writers import write_json
original=ep._BUILDERS['bidirectional_corridor']
def adapted(config,calibration):
    state,walls,dirs=original(config,calibration)
    # Preserve the actual footprint at reset; no dynamic position clipping.
    span=config.half_width-.4-.05
    state[:,1]=np.clip(state[:,1],-span,span)
    state[:,5]=state[:,1]
    return state,[(a,c,b,d) for a,b,c,d in walls],dirs
ep._BUILDERS['bidirectional_corridor']=adapted
CANDIDATES=[['legacy_refit',10.,-.57],['legacy_refit',.003,.375],['true_gradient',.001,.4]]
OUT=Path('../out/narrow_lanes_v2');OUT.mkdir(exist_ok=False)
def task(t):
    candidate,seed,width,calibration=t
    config=ep.ScenarioConfig('bidirectional_corridor',24.,width/2,48,seed,400)
    result=ep.run_scenario(config,calibration,compare.candidate_config(candidate,.65))
    p=result.trajectory.positions;directions=result.trajectory.desired_directions[:,0]
    first=abs(float(np.corrcoef(directions,p[0,:,1])[0,1]))
    metrics=compare.wall_metrics(p,[(-1,width/2,25,width/2),(-1,-width/2,25,-width/2)])
    pair=np.linalg.norm(p[0,:,None,:]-p[0,None,:,:],axis=-1);np.fill_diagonal(pair,np.inf)
    return {'candidate':candidate,'seed':seed,'width_m':width,'persons':48,'calibration':calibration.name,'order_parameters':result.order_parameters,'initial_segregation_index':first,'initial_min_pair_distance_m':float(pair.min()),'initial_footprint_pair_overlaps':int((pair<.8).sum()//2),**metrics}
if __name__=='__main__':
    tasks=[(c,s,w,cal) for c in CANDIDATES for s in compare.SEEDS for w in [3.,3.6] for cal in [ep.RELEASED_DEFAULT_CALIBRATION,ep.LITERATURE_CALIBRATION]]
    print('RESOLVED SEEDS',compare.SEEDS,flush=True)
    rows=[]
    with concurrent.futures.ProcessPoolExecutor(2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(task,t) for t in tasks]):
            r=future.result();rows.append(r);write_json(OUT/f'case_{len(rows):04}.json',r);print('DONE',len(rows),flush=True)
    write_json(OUT/'manifest.json',{'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'slurm_job':os.environ.get('SLURM_JOB_ID'),'seeds':list(compare.SEEDS),'cases':len(rows),'initial_wall_adapter':'clip initial y and goal y to half_width-0.4-0.05; no dynamic clipping'})
