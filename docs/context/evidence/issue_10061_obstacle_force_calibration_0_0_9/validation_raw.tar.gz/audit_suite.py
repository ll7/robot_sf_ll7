import ast,json,pathlib,re
root=pathlib.Path('/home/luttkule/wallcal')
held=lambda n:isinstance(n,int) and (111<=n<=140 or n in {50036,50140,50331,50403,50813,51339,51709,51767,52094,52175,52257,52671,52850,52971,53020,53198,53239,53636,53671,53779,55022,55379,55568,56170,56966,57077,57113,57494,57943,59019})
exclude={
 'tests/test_issue_9724_social_force_resolution_independent.py',
 'tests/scenario_certification/test_feasibility_oracle.py',
 'tests/benchmark/test_map_runner_native_command.py',
 'tests/benchmark/test_hybrid_rule_v4_doorway_regression.py',
 'tests/benchmark/test_replay_noop_fidelity_issue_8568.py',
 'tests/benchmark/test_spawn_overlap_regression_issue_9725.py',
 'tests/test_public_api.py',
 'tests/test_runner_smoke.py',
 'tests/test_baseline_ppo_smoke.py',
 'tests/baselines/test_random_policy.py',
 'tests/test_socnav_env_integration.py',
 'tests/test_occupancy_gymnasium.py',
 'tests/test_env.py',
 'tests/test_lazy_pygame_init.py',
 'tests/test_emergent_phenomena.py',
 'tests/benchmark/test_runner_native_command_arm.py',
 'tests/validation/test_evaluate_predictive_planner_smoke.py',
 'tests/training/test_train_recurrent_ppo_runtime.py',
 'tests/examples/test_examples_run.py',
}
files=[];rows=[]
for p in sorted(root.glob('tests/**/*.py')):
 if not(p.name.startswith('test') or p.name.endswith('_test.py')):continue
 rel=str(p.relative_to(root));s=p.read_text();tree=ast.parse(s);hits=[]
 for n in ast.walk(tree):
  values=[]
  if isinstance(n,ast.Call):
   for kw in n.keywords:
    if kw.arg in {'seed','seeds','random_seed','base_seed','episode_seed','evaluation_seed'}:values.append(kw.value)
  if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and re.search('seed',t.id,re.I) and 'bootstrap' not in t.id.lower() for t in n.targets):values.append(n.value)
  if isinstance(n,ast.Dict):
   values += [v for k,v in zip(n.keys,n.values) if isinstance(k,ast.Constant) and k.value in {'seed','seeds','base_seed','evaluation_seed'}]
  for v in values:
   ints=[t.value for t in ast.walk(v) if isinstance(t,ast.Constant) and held(t.value)]
   if ints:hits.append({'line':n.lineno,'seeds':ints})
 # Mocked orchestration remains eligible: real stepping files are conservatively excluded.
 has_steps=bool(re.search(r'\.step\(|\.learn\(|run_scenario\(|run_multiseed_campaign\(|run_episode\(|_run_map_episode\(|run_feasibility_oracle\(',s))
 if hits and has_steps:exclude.add(rel)
 rows.append({'file':rel,'held_seed_literals':hits,'stepping_calls':has_steps,'excluded':rel in exclude})
 if rel not in exclude:files.append(rel)
(root.parent/'wallcal_artifacts/suite_files.txt').write_text('\n'.join(files)+'\n')
(root.parent/'wallcal_artifacts/suite_excluded.txt').write_text('\n'.join(sorted(exclude))+'\n')
(root.parent/'wallcal_artifacts/suite_seed_audit.json').write_text(json.dumps(rows,indent=2))
print('all',len(rows),'eligible',len(files),'excluded',len(exclude))
