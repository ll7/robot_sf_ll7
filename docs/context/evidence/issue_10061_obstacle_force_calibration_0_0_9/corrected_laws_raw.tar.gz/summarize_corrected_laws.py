"""Compare independent gate outcomes without turning invalid counts into accepted fits."""
from pathlib import Path
from collections import defaultdict
import hashlib,json
import numpy as np
from robot_sf.evidence.writers import write_json
ROOT=Path('/home/luttkule/wallcal_artifacts')
DEST=Path('docs/context/evidence/issue_10061_obstacle_force_calibration_0_0_9')
def load(folder):return [json.loads(p.read_text()) for p in (ROOT/folder).glob('case*.json')]
screen={tuple(r['candidate']):r for r in load('corrected_screen')}
flow=defaultdict(list)
for r in load('corrected_flow'):
    if r['width_m']>=2.4:flow[tuple(r['candidate'])].append(r)
for r in load('seyfried_matched_v2'):flow[tuple(r['candidate'])].append(r)
assert sum(len(v) for v in flow.values())==350
summary=[]
for candidate,rows in flow.items():
    assert len(rows)==70 and {r['seed'] for r in rows}==set(range(1001,1011))
    sr=screen[candidate];a=[r for r in sr['aperture'] if r['width_m']>=1]
    corr=[r for r in sr['wall_cases'] if not r['direct_wall_approach']]
    direct=[r for r in sr['wall_cases'] if r['direct_wall_approach']]
    per=[]
    for width in [.8,1.,1.2,2.4,3.,3.6,5.]:
        cell=[r for r in rows if r['width_m']==width];assert len(cell)==10
        per.append({'width_m':width,'seeds':len(cell),'mean_crossed':float(np.mean([r['crossed'] for r in cell])),'supply':cell[0]['persons'],'complete_runs':sum(r['all_crossed'] for r in cell),'mean_specific_flow_persons_m_s':float(np.mean([r['specific_flow_persons_m_s'] for r in cell])),'mean_central_20_80_specific_flow_persons_m_s':float(np.mean([r['central_20_80_flow_persons_s']/width for r in cell])),'maximum_wall_penetration_m':max(r['wall_penetration_m'] for r in cell),'min_initial_pair_distance_m':min(r['initial_min_pair_distance_m'] for r in cell),'initial_pair_overlap_range':[min(r['initial_footprint_pair_overlaps'] for r in cell),max(r['initial_footprint_pair_overlaps'] for r in cell)]})
    wide=[r for r in per if r['width_m']>=2.4];widths=np.array([r['width_m'] for r in wide]);flows=np.array([r['mean_specific_flow_persons_m_s']*r['width_m'] for r in wide])
    slope,intercept=np.polyfit(widths,flows,1);pred=slope*widths+intercept
    narrow_loss=float(np.mean([(per[i]['mean_specific_flow_persons_m_s']-t)**2 for i,t in enumerate([1.61,1.90,1.97])]))
    drops={str(speed):float(np.mean([r['speed_drop_m_s'] for r in a if r['width_m']==1 and r['desired_speed_m_s']==speed])) for speed in [.65,1.3]}
    summary.append({'candidate':candidate,'accepted':False,'aperture_passes_at_least_1m':sum(r['passed'] for r in a),'aperture_cases_at_least_1m':len(a),'aperture_0_8m_passes':sum(r['passed'] for r in sr['aperture'] if r['width_m']==.8),'mean_1m_speed_drop_m_s':drops,'direct_wall_max_penetration_m':max(r['wall_penetration_m'] for r in direct),'flow_max_penetration_m':max(r['wall_penetration_m'] for r in rows),'steady_corridor_center_range_m':[min(r['steady_center_distance_m'] for r in corr),max(r['steady_center_distance_m'] for r in corr)],'steady_corridor_edge_range_m':[min(r['steady_edge_distance_m'] for r in corr),max(r['steady_edge_distance_m'] for r in corr)],'flow_by_width':per,'provisional_censored_narrow_mse':narrow_loss,'mse_is_valid_complete_experiment_fit':False,'wide_all_data_origin_slope':float(widths@flows/(widths@widths)),'wide_all_data_free_intercept_slope':float(slope),'wide_all_data_free_intercept':float(intercept),'wide_all_data_linear_r2':float(1-np.sum((flows-pred)**2)/np.sum((flows-flows.mean())**2))})
# Dominance uses four explicitly measured diagnostic costs. No trade-off overrides a hard gate.
for r in summary:
    r['diagnostic_cost_vector']=[1-r['aperture_passes_at_least_1m']/r['aperture_cases_at_least_1m'],r['flow_max_penetration_m'],r['provisional_censored_narrow_mse'],abs(r['wide_all_data_origin_slope']-2.3)]
for r in summary:
    x=np.asarray(r['diagnostic_cost_vector']);r['nondominated_in_measured_subset']=not any(np.all(np.asarray(o['diagnostic_cost_vector'])<=x) and np.any(np.asarray(o['diagnostic_cost_vector'])<x) for o in summary if o is not r)
lanes=load('narrow_lanes_v2');lane_summary=[]
for candidate in sorted({tuple(r['candidate']) for r in lanes}):
 for width in [3.,3.6]:
  for cal in ['released_default','literature_typical']:
   cell=[r for r in lanes if tuple(r['candidate'])==candidate and r['width_m']==width and r['calibration']==cal];assert len(cell)==10
   values=[r['order_parameters']['lane_segregation_index'] for r in cell]
   lane_summary.append({'candidate':candidate,'width_m':width,'calibration':cal,'mean_segregation':float(np.mean(values)),'mean_change_from_initial':float(np.mean([r['order_parameters']['lane_segregation_index']-r['initial_segregation_index'] for r in cell])),'weak_or_clear_runs':sum(v>=.15 for v in values),'clear_runs':sum(v>=.5 for v in values),'maximum_wall_penetration_m':max(r['wall_penetration_m'] for r in cell)})
resets=json.loads((ROOT/'gradient_reset'/'manifest_reset.json').read_text())['rows'];assert len(resets)==240
write_json(DEST/'corrected_law_comparison.json',{'evidence_status':'diagnostic-only; physical and empirical admission blocked','accepted_profile':None,'runtime_heads':{folder:json.loads((ROOT/folder/'manifest.json').read_text())['source_head'] for folder in ['corrected_screen','corrected_flow','corrected_lanes','narrow_lanes_v2','seyfried_matched_v2']},'seeds':list(range(1001,1011)),'footprint_radius_m':.4,'force_radius_m':.35,'candidates':summary,'narrow_lanes':lane_summary,'reset_gradient_vs_legacy':{'paired_cases':240,'identical':sum(r['identical_reset_state'] for r in resets),'new_overlaps':sum(r['new_overlap'] for r in resets),'any_profile_overlap':sum(any(c['overlap'] for c in r['clearances'].values()) for r in resets)},'fit_limit':'All candidates fail a hard physical/flow gate. MSE uses censored observed-count flow and is diagnostic only; a mathematical Pareto frontier is not an empirical accepted fit.','raw_archive':'corrected_laws_raw.tar.gz','raw_location':'Tracked archive in this evidence directory preserves every case and exact producer.'})
for r in summary:
 print(r['candidate'],'ap',r['aperture_passes_at_least_1m'],'pen',round(r['flow_max_penetration_m'],4),'Js',[round(x['mean_specific_flow_persons_m_s'],3) for x in r['flow_by_width']],'wide',round(r['wide_all_data_origin_slope'],3),'free',round(r['wide_all_data_free_intercept_slope'],3),'pareto',r['nondominated_in_measured_subset'])
