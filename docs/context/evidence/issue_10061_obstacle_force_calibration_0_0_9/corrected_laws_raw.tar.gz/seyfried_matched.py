"""Correct Figure-2 geometry and central measurement plane for the narrow diagnostic."""
from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess
import numpy as np
from robot_sf.evidence.writers import write_json
from scripts.validation.compare_obstacle_laws_10061 import harness,candidate_config,wall_metrics,RADIUS
def bottleneck(candidate, seed, width, wide=False):
    """Finite-N flow with explicit experiment geometry/supply and density mismatch."""
    rng = np.random.default_rng(seed)
    n = 350 if wide else 60
    length = 1.0 if wide else 2.8
    # A soft-model 3.3/m² initial bulk, not feasible nonoverlapping 0.40 m discs.
    density = 3.0 if wide else 3.3
    if wide:
        # Liao holding semicircle: radius 8.618 m, N=350, density 3/m².
        # Deterministic hex sites within the semicircle; jitter is seed controlled.
        radius = 8.618
        spacing = (2 / (np.sqrt(3) * density)) ** 0.5 * 0.94
        sites = []
        for row in range(-18, 19):
            yy = row * spacing * np.sqrt(3) / 2
            for column in range(-20, 1):
                xx = (column + (row % 2) * 0.5) * spacing
                if xx < -0.42 and xx * xx + yy * yy < radius * radius:
                    sites.append((xx, yy))
        sites = np.asarray(sites)[rng.choice(len(sites), n, replace=False)]
        if len(sites) != n:
            raise ValueError("insufficient semicircle sites")
        x, y = sites[:, 0], sites[:, 1]
        half = 10.0
    else:
        # Figure 2: 4 m upstream corridor, three N=20 holding sections.
        holding_width = 4.
        holding_length = n/(holding_width*density)
        section_length = holding_length/3
        bulk_center = -3.-section_length
        xx,yy=np.meshgrid(np.linspace(bulk_center-holding_length/2+.45,bulk_center+holding_length/2-.45,10),np.linspace(-1.55,1.55,6))
        x,y=xx.ravel(),yy.ravel()
        half=2.
    x = x + rng.uniform(-0.01, 0.01, n)
    y = y + rng.uniform(-0.01, 0.01, n)
    downstream = length + 20.0
    segments = [
        (-50.0, half, downstream, half),
        (-50.0, -half, downstream, -half),
        (0.0, width / 2, 0.0, half),
        (0.0, -half, 0.0, -width / 2),
        (0.0, width / 2, length, width / 2),
        (0.0, -width / 2, length, -width / 2),
    ]
    state = np.column_stack(
        [
            x,
            y,
            np.full(n, (1.55 if wide else 1.3) / 1.3),
            np.zeros(n),
            np.full(n, length + 0.6),
            np.clip(y, -max(0.0, width / 2 - RADIUS - 0.05), max(0.0, width / 2 - RADIUS - 0.05)),
            np.full(n, 0.5),
        ]
    )

    def update(sim):
        passed = sim.peds.pos()[:, 0] > length + 0.2
        sim.peds.state[passed, 4] = downstream

    positions, _ = harness.simulate(
        state,
        segments,
        candidate_config(candidate, 1.55 if wide else 1.3),
        1600,
        goal_update=update,
    )
    # Seyfried calls the measuring plane the channel centre; y=0.4 is its local video coordinate.
    plane = length if wide else length/2
    times = []
    for j in range(n):
        index = np.flatnonzero(positions[:, j, 0] >= plane)
        if len(index):
            k = int(index[0])
            previous = positions[k - 1, j, 0] if k else plane
            fraction = (plane - previous) / (positions[k, j, 0] - previous) if k else 0.0
            times.append(float((k - 1 + fraction) * 0.1))
    times.sort()
    count = len(times)
    flow = count / (times[-1] - times[0]) if count >= 2 else 0.0
    central = times[int(0.2 * count) : int(0.8 * count)]
    central_flow = (len(central) - 1) / (central[-1] - central[0]) if len(central) >= 2 else 0.0
    delta = state[:, None, :2] - state[None, :, :2]
    pair = np.linalg.norm(delta, axis=-1)
    np.fill_diagonal(pair, np.inf)
    return {
        "candidate": candidate,
        "seed": seed,
        "width_m": width,
        "bottleneck_length_m": length,
        "persons": n,
        "initial_density_m2": density,
        "desired_speed_m_s": 1.55 if wide else 1.3,
        "initial_min_pair_distance_m": float(pair.min()),
        "initial_footprint_pair_overlaps": int((pair < 2 * RADIUS).sum() // 2),
        "crossing_plane_m": plane,
        "upstream_width_m":2*half,
        "holding_section_count":3,
        "first_holding_section_center_upstream_m":3.,
        "geometry_source":"Seyfried Figure 2, 4 m corridor and N=20 holding sections; physical initial wall margin adapted for fixed 0.40 m body",
        "crossed": count,
        "all_crossed": count == n,
        "flow_persons_s": flow,
        "specific_flow_persons_m_s": flow / width,
        "central_20_80_flow_persons_s": central_flow,
        "central_period_is_proven_stationary": False,
        "crossing_times_s": times,
        **wall_metrics(positions, segments),
    }

if __name__=="__main__":
    out=Path('../out/seyfried_matched_v2');out.mkdir(exist_ok=False)
    grid=json.loads(Path('../pareto_flow_grid.json').read_text())
    seeds=list(range(1001,1011));tasks=[(c,s,w) for c in grid for s in seeds for w in [.8,1.,1.2]]
    print('RESOLVED SEEDS',seeds,flush=True)
    records=[]
    with concurrent.futures.ProcessPoolExecutor(6) as pool:
        futures=[pool.submit(bottleneck,c,s,w) for c,s,w in tasks]
        for future in concurrent.futures.as_completed(futures):
            record=future.result();records.append(record);write_json(out/f'case_{len(records):04}.json',record);print('DONE',len(records),flush=True)
    write_json(out/'manifest.json',{'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'seeds':seeds,'slurm_job':os.environ.get('SLURM_JOB_ID'),'cases':len(records),'geometry':'Figure-2 4 m corridor, three holding sections, channel-centre measurement; fixed body wall margin explicit'})
